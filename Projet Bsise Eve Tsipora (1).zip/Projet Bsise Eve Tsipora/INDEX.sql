/*create index I
on event(price);*/

create index IEventDate
on event(datee);


create index IEventID
on event(SORTT);

create index IEventPrice   /* il est bien cet index*/
on event(price);


create index IEmpName      /* il est bien cet index*/
on Employees(employee_name );



create index IEmpSalary        /* il est pas super cool cet index*/
on Employees(salary );



create index IVisitGend      /* good*/
on VISITOR(Gender);


create index IEventCity
on event(CITY);

create index IEventVisitor
on event(visitor_id);

create index ICardValid  /* il est pas bien cet index*/
on card(valid);



create index ICreditCard /*a voir*/
on card(CREDIT_CARD_TYPE);



create index INumberCard /*IL MARCHE PAS*/
on card(NUMBER_CARD);





create index IEmpHireYear       /* il est pas bien cet index*/
on Employees(hire_year );



create index IEmpAddress       /* pas top*/
on Employees(Address);



create index IVisitAge      /* nul */
on VISITOR(Age);

create index IVisitName        /* nul */
on VISITOR(name_visitor );



create index IVisitNumCard    
on VISITOR(number_card  );  /* nul */




create index IVisitID   
on VISITOR(visitor_id   );  /* MARCHE PAS */




drop index IEVENTID;
drop index IEventCity;
drop index IEventPrice;
drop index INUMBERCARD;
drop index IEVENTDATE;
drop index IEventVisitor;
drop index ICardValid;
drop index ICreditCard;
drop index IEmpName;
drop index IEmpSalary;
drop index IEmpHireYear ;
drop index IEmpAddress ;
drop index IVisitGend ;
drop index IVisitAge ;
drop index IVisitName ;
drop index IVisitNumCard ;

 
