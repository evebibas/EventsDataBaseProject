SELECT V.NAME_VISITOR, V.VISITOR_ID, V.AGE
FROM VISITOR V natural join CARD C 
WHERE C.VALID = 'true'  AND C.CREDIT_CARD_TYPE = 'americanexpress'                   
ORDER BY C.CREDIT_CARD_TYPE ASC

/* Tous les visitors qui ont une carte bleu valide et de American Express */
