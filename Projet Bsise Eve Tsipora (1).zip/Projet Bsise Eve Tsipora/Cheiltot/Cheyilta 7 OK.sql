SELECT  E.EMPLOYEE_NAME, E.EMPLOYEES_ID, E.ADDRESS
FROM EMPLOYEES E
WHERE E.HIRE_YEAR > 2017 AND E.ADDRESS LIKE '%com' OR  E.ADDRESS LIKE '%it' OR  E.ADDRESS LIKE '%org'


/* Tous les employes qui ont une adresse mail qui se termine par com ou par org */ 

