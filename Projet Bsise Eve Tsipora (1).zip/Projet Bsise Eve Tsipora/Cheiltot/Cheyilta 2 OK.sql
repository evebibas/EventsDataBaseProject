SELECT V.NAME_VISITOR, E.DATEE, E.SORTT, E.CITY
FROM EVENT E NATURAL JOIN VISITOR V 
WHERE E.Datee BETWEEN TO_DATE('2022-06-01','YYYY-MM-DD') AND TO_DATE('2022-09-30','YYYY-MM-DD') 
AND (E.SORTT = 'Wedding' OR E.SORTT = 'Brit Mila' )
ORDER BY E.DATEE;
/* Tous les Visitor qui ont pris de evenement entre le 01 Juin 2022 et le 30 sept 2022*/
