SELECT  V.NAME_VISITOR, V.VISITOR_ID, V.NUMBER_CARD
FROM VISITOR V
WHERE V.VISITOR_ID IN (SELECT E1.VISITOR_ID
              FROM EVENT E1
             WHERE E1.PRICE < 220);



/* Tous les Visitor qui ont un evenement avec une mana qui coute moins de 220 sh  */
