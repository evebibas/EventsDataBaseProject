SELECT V1.VISITOR_ID, V1.NAME_VISITOR, V1.NUMBER_CARD
FROM VISITOR V1 
WHERE V1.VISITOR_ID IN
      (select V.VISITOR_ID
       FROM VISITOR V
       WHERE V.Age < 30
       INTERSECT
       select E.VISITOR_ID
       FROM EVENT E
       WHERE E.PRICE > 400);
       
       
       /* Tous les visitor qui ont moins de 30 ans et qui ont un evenement a plus de 400 sh la mana*/
