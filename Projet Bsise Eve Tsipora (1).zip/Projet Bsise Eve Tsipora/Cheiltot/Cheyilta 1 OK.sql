SELECT Distinct V.NAME_VISITOR,  V.AGE
FROM Visitor V
WHERE V.AGE > 30 AND V.AGE < 45 AND V.GENDER= 'F';


/*Tous les visitors femmes qui ont entre 30 et 45 ans*/
