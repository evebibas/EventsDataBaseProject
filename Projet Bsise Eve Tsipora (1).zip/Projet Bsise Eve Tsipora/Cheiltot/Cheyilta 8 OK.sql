

SELECT V.VISITOR_ID, V.NAME_VISITOR, C.credit_card_type
FROM VISITOR V NATURAL JOIN CARD C 
WHERE C.VALID = 'true' AND (V.AGE <28 OR C.CREDIT_CARD_TYPE = 'visa-electron')


/* Tous les visitor qui ont une carte bleue valide et qui sont etudiant ou qui ont une carte bleu pas VisaElectron alors on leur donne une bourses */
