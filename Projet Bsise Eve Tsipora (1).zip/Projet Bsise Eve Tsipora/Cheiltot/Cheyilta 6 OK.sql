
SELECT E1.EMPLOYEE_NAME, E1.SALARY, E1.employees_id
FROM EMPLOYEES E1
WHERE  (E1.SALARY BETWEEN 5500 AND 9000 ) AND ( E1.HIRE_YEAR > 2016)
ORDER BY E1.SALARY ASC

/* Tous les emplyes qui ont pas un salaire entre 5500 ET 9000 et qui  ont un hireYear plus grand que 2016 */
