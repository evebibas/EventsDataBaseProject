--View2

CREATE VIEW ViewEvent
( Employee_Name, Salary, Hire_Year,Datee,Price,Name_Visitor ,AgeVisitor, Num_Card_Visitor)
AS SELECT  Employee_Name, Salary, Hire_Year,Datee,Price, Name_Visitor ,Age, Number_Card
   FROM Employees E1, Event E2, Visitor V
   WHERE E1.EMPLOYEES_ID= E2.EMPLOYEES_ID AND V.VISITOR_ID=E2.VISITOR_ID
   AND E2.PRICE<500 AND V.AGE<26  
   
--Query1
Select Hire_Year, round(avg(Salary)) as AvgSalary
From ViewEvent
GROUP BY Hire_Year
ORDER BY Hire_Year

--Query2
Select Name_Visitor, datee, price, AgeVisitor, Num_Card_Visitor
From ViewEvent

   
   
Select * from ViewEvent
DROP VIEW ViewEvent;
