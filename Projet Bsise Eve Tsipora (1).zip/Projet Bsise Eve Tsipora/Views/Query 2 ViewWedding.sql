
--QUERY2
Select Datee, NameVisitor, Sortt, City, EventId
From ViewWedding V
Where V.datee  BETWEEN TO_DATE('2022-08-01','YYYY-MM-DD') AND TO_DATE('2022-08-31','YYYY-MM-DD')
ORDER BY datee
