  
--Query1
Select Hire_Year, round(avg(Salary)) as AvgSalary
From ViewEvent
GROUP BY Hire_Year
ORDER BY Hire_Year
