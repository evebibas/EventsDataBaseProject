 
--QUERY1
Select Datee, round (avg(price))
From ViewWedding
GROUP BY Datee 
ORDER BY Datee
