
--Query2
Select Name_Visitor, datee, price, AgeVisitor, Num_Card_Visitor
From ViewEvent
