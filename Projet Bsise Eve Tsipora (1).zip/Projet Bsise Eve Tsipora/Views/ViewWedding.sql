--View1

CREATE VIEW ViewWedding
(Datee,Sortt,EventId,City,Price, NameVisitor)
AS SELECT Datee,Sortt,Event_Id,City,Price, Name_Visitor
   FROM Visitor V, Event E
   WHERE V.VISITOR_ID= E.VISITOR_ID
   AND (E.SORTT='Wedding' OR E.SORTT='Houppa')
   
--QUERY1
Select Datee, round (avg(price))
From ViewWedding
GROUP BY Datee 
ORDER BY Datee

--QUERY2
Select Datee, NameVisitor, Sortt, City, EventId
From ViewWedding V
Where V.datee  BETWEEN TO_DATE('2022-08-01','YYYY-MM-DD') AND TO_DATE('2022-08-31','YYYY-MM-DD')
ORDER BY datee

Select * from ViewWedding
DROP VIEW ViewWedding;
