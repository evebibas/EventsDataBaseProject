select  Emp.EMPLOYEES_ID, S.ENTRY_TIME, S.LEAVING_TIME, S.STAND_ID, Emp.Salary 
from Employees Emp , Yashtain.Workers W, Yashtain.Shift S
where Emp.EMPLOYEES_ID = W.Worker_Id AND W.Worker_Id=S.WORKER_ID AND S.ENTRY_TIME BETWEEN TO_DATE('2022-03-15','YYYY-MM-DD') AND TO_DATE('2022-08-31','YYYY-MM-DD')

