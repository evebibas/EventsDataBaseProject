select E.CITY, S.STAND_ID, E.DATEE, E.SORTT
from Yashtain.Food_Stand S,  Event E
Where S.LOCATION = E.CITY AND E.PRICE > 450 
