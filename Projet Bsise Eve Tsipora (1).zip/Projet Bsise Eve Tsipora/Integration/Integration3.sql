select  *
from Yashtain.Visitors YV , Employees Emp
where YV.VISITOR_ID = Emp.Employees_Id and Emp.Hire_Year > 2010
