select * from VISITOR;
select * from CARD;
select * from EMPLOYEES;
select * from EVENT;

select salary from Employees Emp where Emp.Employees_Id=980;
select *
from Event E natural join (select salary from Employees Emp where Emp.Employees_Id=980)
where E.EMPLOYEES_ID=980;
